import torch

def gradientDescentPyTorchRegression(X, y, alpha=0.1, num_iters=1500):
    # 1. Convert data to tensors
    X_t = torch.tensor(X, dtype=torch.float32)
    y_t = torch.tensor(y, dtype=torch.float32)
    
    # Add a column of ones for the bias (intercept)
    ones = torch.ones((X_t.shape[0], 1))
    X_b = torch.cat((ones, X_t), dim=1)
    
    # 2. Initialize Theta with requires_grad=True to enable Autograd
    theta = torch.zeros((X_b.shape[1], 1), requires_grad=True)
    
    # 3. Training Loop
    for i in range(num_iters):
        # Forward pass: predictions
        predictions = torch.matmul(X_b, theta)
        
        # Calculate Loss (Mean Squared Error)
        loss = torch.mean((predictions - y_t) ** 2)
        
        # Autograd: calculate gradients automatically
        loss.backward()
        
        # Update Theta (using no_grad to avoid tracking this calculation)
        with torch.no_grad():
            theta -= alpha * theta.grad
            # Reset gradients for next iteration
            theta.grad.zero_()
            
    return theta

# --- Example Usage ---
X_data = [[1.0], [2.0], [3.0], [4.0]]
y_data = [[6.0], [5.0], [11.0], [9.0]]

final_theta = gradientDescentPyTorchRegression(X_data, y_data)
print("Final Optimized Parameters:")
print(final_theta)
