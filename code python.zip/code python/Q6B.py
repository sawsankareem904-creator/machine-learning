import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# 1. Data (from Question 1)
x = np.array([1, 2, 3, 4, 5])
y = np.array([2, 4, 5, 4, 5])

# 2. Gradient Descent Setup
def compute_cost(theta0, theta1, x, y):
    m = len(x)
    return (1/(2*m)) * np.sum((theta0 + theta1 * x - y)**2)

# Gradient Descent Parameters
learning_rate = 0.05
iterations = 50
theta0, theta1 = 0.0, 0.0
path = [(theta0, theta1)]

for _ in range(iterations):
    m = len(x)
    predictions = theta0 + theta1 * x
    d_theta0 = (1/m) * np.sum(predictions - y)
    d_theta1 = (1/m) * np.sum((predictions - y) * x)
    theta0 -= learning_rate * d_theta0
    theta1 -= learning_rate * d_theta1
    path.append((theta0, theta1))

# 3. Setup Plots
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

# Left: Contour Plot
theta0_vals = np.linspace(-2, 8, 100)
theta1_vals = np.linspace(-2, 4, 100)
T0, T1 = np.meshgrid(theta0_vals, theta1_vals)
RSS = np.array([[(np.sum((t0 + t1 * x - y)**2)) for t1 in theta1_vals] for t0 in theta0_vals]).T
ax1.contour(T0, T1, RSS, levels=20, cmap='viridis')
path_line, = ax1.plot([], [], 'r-', marker='o', markersize=4)
ax1.set_xlabel('theta0')
ax1.set_ylabel('theta1')

# Right: Regression Line
ax2.scatter(x, y, color='blue')
line, = ax2.plot([], [], 'r-')
ax2.set_xlim(0, 6)
ax2.set_ylim(0, 7)

# Animation Update Function
def update(frame):
    t0, t1 = path[frame]
    # Update Contour Path
    path_data = np.array(path[:frame+1])
    path_line.set_data(path_data[:, 0], path_data[:, 1])
    # Update Regression Line
    line.set_data(x, t0 + t1 * x)
    cost = compute_cost(t0, t1, x, y)
    fig.suptitle(f'Iteration: {frame} | Cost: {cost:.4f}')
    return path_line, line

ani = FuncAnimation(fig, update, frames=len(path), interval=200, blit=True)
plt.show()
