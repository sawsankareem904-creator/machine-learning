

import time
import torch
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.datasets import fetch_california_housing

# 1. Load Data (Real Estate Valuation Dataset)
data = fetch_california_housing()
X = data.data
y = data.target

# 2. Scikit-Learn Linear Regression (Benchmark)
# This represents the internal standard implementation
start_sklearn = time.time()
sklearn_model = LinearRegression().fit(X, y)
sklearn_preds = sklearn_model.predict(X)
end_sklearn = time.time()

sklearn_mse = mean_squared_error(y, sklearn_preds)
sklearn_time = end_sklearn - start_sklearn

# 3. Custom PyTorch Implementation
# This uses your Gradient Descent with Autograd logic
X_tensor = torch.tensor(X, dtype=torch.float32)
y_tensor = torch.tensor(y, dtype=torch.float32).view(-1, 1)

start_pytorch = time.time()
# Initialize weights
theta = torch.zeros((X_tensor.shape[1], 1), requires_grad=True)
learning_rate = 0.0000001 # Small rate for this specific dataset scale
optimizer = torch.optim.SGD([theta], lr=learning_rate)

# Iterative Gradient Descent
for i in range(1000):
    preds = torch.matmul(X_tensor, theta)
    loss = torch.mean((preds - y_tensor) ** 2)
    loss.backward()
    optimizer.step()
    optimizer.zero_grad()
    
end_pytorch = time.time()

pytorch_preds = torch.matmul(X_tensor, theta).detach().numpy()
pytorch_mse = mean_squared_error(y, pytorch_preds)
pytorch_time = end_pytorch - start_pytorch

# 4. Report Results
print("--- Performance Comparison Report ---")
print(f"Method          | Time (s) | MSE")
print(f"------------------------------------")
print(f"Scikit-Learn    | {sklearn_time:.6f} | {sklearn_mse:.4f}")
print(f"Custom PyTorch  | {pytorch_time:.6f} | {pytorch_mse:.4f}")
