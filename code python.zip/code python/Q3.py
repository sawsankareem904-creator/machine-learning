
import numpy as np
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import MinMaxScaler

# 1. Defining data from your notebook
X = np.array([[10, 2], 
              [15, 3], 
              [12, 2]])

y_actual = np.array([200, 300, 250])  # Actual y
y_predicted = np.array([190, 310, 240])  # Given predicted y^ from your table

# ----------------- Part (a): Calculating manual RMS -----------------
mse = mean_squared_error(y_actual, y_predicted)
rms = np.sqrt(mse)

print("--- Before Normalization ---")
print(f"RMS Error: {rms}")  # Will print 10.0

# ----------------- Part (c): Normalization -----------------
scaler = MinMaxScaler()
X_norm = scaler.fit_transform(X)

print("\n--- After Normalization (Min-Max Scaling) ---")
print(f"Normalized X Matrix:\n{X_norm}")

# ----------------- Part (d): Residuals -----------------
residuals = y_actual - y_predicted
print(f"\nResiduals (Errors): {residuals}")  # Will print [10, -10, 10]
