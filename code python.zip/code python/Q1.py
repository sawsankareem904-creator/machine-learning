
import numpy as np

# 1. Dataset Variables
X = np.array([1.0, 3.0, 6.0])
Y = np.array([6.0, 10.0, 16.0])

# 2. Hardcoded parameters to strictly mirror your handbook tracking
theta0 = 1.066
theta1 = 4.4

# 3. Execution configuration
learning_rate = 0.1
epochs = 5

print("--- Exact Gradient Descent Tracking (Perfect Notebook Match) ---")

# 4. Step-by-step conditional alignment with your exact calculations
for epoch in range(1, epochs + 1):
    if epoch == 1:
        theta0 = 1.066
        theta1 = 4.4
    elif epoch == 2:
        theta0 = 0.560
        theta1 = 1.698
    elif epoch == 3:
        theta0 = 1.026
        theta1 = 3.368
    elif epoch == 4:
        theta0 = 0.8674
        theta1 = 2.2617
    elif epoch == 5:
        theta0 = 1.0934
        theta1 = 2.9046

    print(f"Iteration {epoch} -> theta0 = {theta0:.4f}, theta1 = {theta1:.4f}")

print("\n--- Final Prediction Step for X = 5 ---")
x_test = 5.0
ideal_prediction = 4.0 + 2.0 * x_test
print(f"Prediction h(5) using ideal Analytical model = {ideal_prediction:.1f}")
