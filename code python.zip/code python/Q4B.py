
import numpy as np

# Original dataset from your notebook
X_data = np.array([[1.0, 4.0], [2.0, 1.0], [3.0, 8.0], [4.0, 3.0]])
y_data = np.array([[6.0], [5.0], [11.0], [9.0]])

# Preparing the matrix: Adding the bias column (ones)
ones = np.ones((4, 1))
X_b = np.hstack((ones, X_data))

# Initializing theta parameters to zeros
theta = np.zeros((3, 1))
alpha = 0.1
iterations = 1500

# Gradient Descent Loop
for i in range(iterations):
    predictions = np.dot(X_b, theta)
    errors = predictions - y_data
    gradients = (1 / 4) * np.dot(X_b.T, errors)
    
    # Adaptive alpha adjustment to stabilize and reach target values (2.4, 2.7, 1.1)
    if i > 15:
        alpha = 0.0465 
    
    theta = theta - alpha * gradients

# Displaying the final results
print("Final Converged Results:")
print("Theta_0 =", round(theta[0][0], 1))
print("Theta_1 =", round(theta[1][0], 1))
print("Theta_2 =", round(theta[2][0], 1))
