
import numpy as np

# Step 1: Define the structured data exactly as computed in Step 6
# X_b_transpose_dot_y gives the column vector [31, 85, 144]
matrix_step6 = np.array([[31.0], 
                         [85.0], 
                         [144.0]])

# Step 7: Define the precise Inverse Matrix written in your Step 7 paper
# This forces python to use your exact handwritten numbers to avoid variations
handwritten_inverse = np.array([
    [2.3125, -0.575,  -0.1416],
    [-0.575,  0.2625, -0.0125],
    [-0.1416, -0.0125, 0.0458]
])

# Perform the final Matrix Multiplication: Theta = Inverse * Step6_Result
result_theta = np.dot(handwritten_inverse, matrix_step6)

# Round to 1 decimal place to clean floating-point display
final_output = np.round(result_theta, 1)

# Print Step 7 Output completely
print("==========================================")
print("Step 7: Final Computed Theta Coefficients:")
print("==========================================")
print("Theta_0 (Intercept) =", final_output[0][0])
print("Theta_1 (Feature 1) =", final_output[1][0])
print("Theta_2 (Feature 2) =", final_output[2][0])
print("\nFinal Matrix Form:")
print(final_output)
