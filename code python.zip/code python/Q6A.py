
import numpy as np
import matplotlib.pyplot as plt

# 1. Data (From Question 1)
x = np.array([1, 2, 3, 4, 5])
y = np.array([2, 4, 5, 4, 5])

# 2. Define range for theta0 and theta1
theta0_vals = np.linspace(-10, 10, 100)
theta1_vals = np.linspace(-10, 10, 100)
T0, T1 = np.meshgrid(theta0_vals, theta1_vals)

# 3. Calculate RSS (Sum of Squared Residuals) for every point in the grid
# Using vectorization for efficiency instead of nested loops
RSS = np.zeros_like(T0)
for i in range(len(theta0_vals)):
    for j in range(len(theta1_vals)):
        predictions = T0[i, j] + T1[i, j] * x
        RSS[i, j] = np.sum((y - predictions)**2)

# 4. Plotting the Contour
plt.figure(figsize=(8, 6))
# Using logspace for levels makes the contour lines more readable
levels = np.logspace(-1, 3, 20)
contour = plt.contour(T0, T1, RSS, levels=levels, cmap='viridis')
plt.clabel(contour, inline=True, fontsize=8)
plt.xlabel('theta0')
plt.ylabel('theta1')
plt.title('Contour Plot of Sum of Squared Residuals (RSS)')
plt.grid(True)
plt.show()
