
import torch

# 1. Define the Data (X and y)
# We convert our data to tensors, which is the PyTorch format
X_data = [[1.0], [2.0], [3.0], [4.0]]
y_data = [[6.0], [5.0], [11.0], [9.0]]

X_t = torch.tensor(X_data, dtype=torch.float32)
y_t = torch.tensor(y_data, dtype=torch.float32)

# Add a column of ones for the bias term (intercept)
X_b = torch.cat([torch.ones(X_t.shape[0], 1), X_t], dim=1)

# 2. Initialize Theta (Weights)
# We set requires_grad=True so PyTorch tracks all operations for autograd
theta = torch.zeros((2, 1), requires_grad=True)
learning_rate = 0.05
iterations = 1000

# 3. Gradient Descent Loop
for i in range(iterations):
    # Calculate predictions (Linear Regression formula: y = X * theta)
    predictions = torch.matmul(X_b, theta)
    
    # Calculate the Loss (Mean Squared Error)
    loss = torch.mean((predictions - y_t) ** 2)
    
    # Autograd: Automatically calculate gradients (the derivatives)
    loss.backward()
    
    # Update Theta using the calculated gradients
    with torch.no_grad():
        theta -= learning_rate * theta.grad
        # Zero out gradients for the next iteration
        theta.grad.zero_()

print("Final Theta values (Bias, Weight):")
print(theta)
