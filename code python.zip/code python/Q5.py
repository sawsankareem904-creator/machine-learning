
import torch
import numpy as np

# 1. Generate Data
np.random.seed(0)
x_np = np.arange(0, 20.1, 0.1)
# Corrected the exponents using ** operator
y_np = 1 *(x_np**5) + 3 *( x_np**4) - 100 *(x_np**3) + 8 *(x_np**2) - 300 *x_np - 1e5 + np.random.randn(len(x_np))*1e5

# 2. Function to perform Polynomial Regression
def train_poly(p):
    # Create Feature Matrix X: [1, x, x^2, ..., x^p]
    X_list = [x_np**i for i in range(p + 1)]
    X = np.column_stack(X_list)
    
    X_tensor = torch.tensor(X, dtype=torch.float32)
    y_tensor = torch.tensor(y_np, dtype=torch.float32).view(-1, 1)
    
    # Initialize weights (theta)
    # Using a small initialization to keep values stable
    theta = torch.zeros((p + 1, 1), requires_grad=True)
    
    # Optimizer settings
    optimizer = torch.optim.SGD([theta], lr=1e-12)
    
    # Training Loop
    for i in range(10000):
        preds = torch.matmul(X_tensor, theta)
        loss = torch.mean((preds - y_tensor) ** 2)
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
    
    return theta.detach().numpy().flatten()

# 3. Run for p=5 and p=4
theta_p5 = train_poly(5)
theta_p4 = train_poly(4)

# 4. Compare Results
true_coeffs = [1, 3, -100, 8, -300, -100000]
print("--- Polynomial Regression Results ---")
print(f"True Coefficients: {true_coeffs}")
print(f"Estimated (p=5):   {np.round(theta_p5, 2)}")
print(f"Estimated (p=4):   {np.round(theta_p4, 2)}")
