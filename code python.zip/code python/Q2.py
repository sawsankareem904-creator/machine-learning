
import numpy as np
from sklearn.linear_model import LinearRegression

# Define the data provided in the question
X = np.array([[1, 2],
              [2, 4],
              [3, 6],
              [4, 8]])

y = np.array([2, 3, 4, 5])

# Train the model
model = LinearRegression()
model.fit(X, y)

# Print the results accurately
print(f"Intercept: {model.intercept_:.1f}")
print(f"Coefficients: {model.coef_}")
